@echo off
chcp 65001 >nul
cd /d "%~dp0"
title MikroTik Scanner Local Agent
echo ============================================
echo  MikroTik Scanner - Local Agent
echo  UI+API: http://127.0.0.1:8001/
echo ============================================

if exist MikroTikScannerAgent.exe (
  echo Starting MikroTikScannerAgent.exe ...
  start http://127.0.0.1:8001/
  MikroTikScannerAgent.exe
  pause
  exit /b 0
)

where py >nul 2>&1 && set "PY=py -3"
if not defined PY where python >nul 2>&1 && set "PY=python"
if not defined PY (
  echo [ERROR] Python 3.10+ required, or place MikroTikScannerAgent.exe here.
  pause
  exit /b 1
)

echo Using: %PY%
%PY% --version
if not exist .venv (
  echo [1/3] Creating .venv ...
  %PY% -m venv .venv || (pause & exit /b 1)
) else (
  echo [1/3] .venv exists
)
call .venv\Scripts\activate.bat
echo [2/3] Installing deps (first run may take a few minutes)...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt || (echo pip failed & pause & exit /b 1)
echo [3/3] Starting...
echo After "Uvicorn running" open: http://127.0.0.1:8001/
start http://127.0.0.1:8001/
python agent_main.py
pause
