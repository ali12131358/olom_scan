================================================
  MikroTik Scanner — Local Agent (+ UI)
================================================

Agent هم API و هم رابط وب را روی این کامپیوتر اجرا می‌کند.

اجرا:
  Windows:  start_backend.bat
  Linux:    ./start_backend.sh

سپس در مرورگر باز کنید (حتماً همین آدرس محلی):
  http://127.0.0.1:8001/

چرا نه آدرس سرور عمومی؟
  Chrome/Edge به صفحهٔ عمومی اجازه نمی‌دهد به 127.0.0.1
  وصل شود. با باز کردن UI از localhost مشکل حل است.
  VPN هم اینترنت سرور را قطع می‌کند؛ Agent محلی می‌ماند.

ساخت exe: build_exe.bat → dist\MikroTikScannerAgent.exe
