"""Local Agent entrypoint (script or PyInstaller exe)."""
from __future__ import annotations
import os, sys
from pathlib import Path

def _prepare_paths() -> Path:
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        root = Path(sys._MEIPASS)
    else:
        root = Path(__file__).resolve().parent
    for p in (str(root), str(root / "backend")):
        if p not in sys.path:
            sys.path.insert(0, p)
    if getattr(sys, "frozen", False):
        os.chdir(Path(sys.executable).resolve().parent)
    else:
        os.chdir(root)
    return root

def main() -> None:
    _prepare_paths()
    try:
        import uvicorn
    except ImportError:
        raise SystemExit("uvicorn missing. Run: pip install -r requirements.txt")
    host = os.environ.get("AGENT_HOST", "127.0.0.1")
    port = int(os.environ.get("AGENT_PORT", "8001"))
    print("=" * 52)
    print("  MikroTik Scanner — Local Agent")
    print(f"  API + UI:  http://{host}:{port}/")
    print(f"  Health:    http://{host}:{port}/health")
    print()
    print("  IMPORTANT: Open the UI from the LOCAL address above.")
    print("  Do NOT use the public server URL in the browser")
    print("  (Chrome blocks public sites from talking to localhost).")
    print("  Keep this window OPEN. Ctrl+C to stop.")
    print("=" * 52)
    try:
        from backend.main import app
    except ImportError:
        import main as backend_main  # type: ignore
        app = backend_main.app
    uvicorn.run(app, host=host, port=port, reload=False, log_level="info")

if __name__ == "__main__":
    main()
