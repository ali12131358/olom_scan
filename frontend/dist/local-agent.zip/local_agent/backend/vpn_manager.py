"""Local VPN lifecycle manager. Commands are invoked without a shell; only one tunnel is managed."""
from __future__ import annotations
import json, os, platform, re, shutil, subprocess, threading, time, ipaddress
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
PROFILE_FILE=Path(os.environ.get("MIKROTIK_VPN_PROFILES", ROOT/"vpn_profiles.json"))
LOCK=threading.RLock()
ACTIVE=None
PROFILES={}
_ALLOWED={"wireguard","openvpn","pptp","l2tp","sstp"}
_ID=re.compile(r"^[a-zA-Z0-9_-]{1,48}$")

def _load():
    global PROFILES
    try:
        value=json.loads(PROFILE_FILE.read_text(encoding="utf-8"))
        PROFILES=value if isinstance(value,dict) else {}
    except (OSError,ValueError): PROFILES={}

def _save():
    PROFILE_FILE.parent.mkdir(parents=True,exist_ok=True)
    tmp=PROFILE_FILE.with_suffix(PROFILE_FILE.suffix+".tmp")
    tmp.write_text(json.dumps(PROFILES,ensure_ascii=False,indent=2),encoding="utf-8")
    try: os.chmod(tmp,0o600)
    except OSError: pass
    tmp.replace(PROFILE_FILE)

def _safe_config(text, suffix):
    if not isinstance(text,str) or not text.strip() or len(text)>200_000: raise ValueError("فایل پیکربندی خالی یا بزرگ است")
    if "\x00" in text: raise ValueError("پیکربندی نامعتبر است")
    folder=ROOT/".vpn_runtime"; folder.mkdir(mode=0o700,exist_ok=True)
    try: os.chmod(folder,0o700)
    except OSError: pass
    path=folder/ ("active"+suffix)
    path.write_text(text,encoding="utf-8")
    try: os.chmod(path,0o600)
    except OSError: pass
    return path

def _routes(value):
    if value in (None,""): return []
    if isinstance(value,str): value=[x.strip() for x in value.split(",") if x.strip()]
    if not isinstance(value,list) or len(value)>64: raise ValueError("حداکثر ۶۴ مسیر مجاز است")
    try: return [str(ipaddress.ip_network(x,strict=False)) for x in value]
    except ValueError: raise ValueError("مسیر شبکه باید CIDR معتبر باشد")

def connect(config):
    global ACTIVE
    if not isinstance(config,dict): raise ValueError("پارامترهای VPN نامعتبرند")
    protocol=str(config.get("protocol","")).lower()
    if protocol not in _ALLOWED: raise ValueError("پروتکل پشتیبانی‌نشده است")
    routes=_routes(config.get("routes"))
    with LOCK:
        if ACTIVE and ACTIVE.get("connected"): raise RuntimeError("یک اتصال VPN از قبل فعال است")
        kind=platform.system().lower(); proc=None; name=str(config.get("name") or "Remote VPN")[:64]
        if protocol=="wireguard":
            if kind=="windows":
                exe=shutil.which("wireguard")
                if not exe: raise RuntimeError("WireGuard for Windows نصب نیست")
                cfg=_safe_config(config.get("config_content"),".conf")
                result=subprocess.run([exe,"/installtunnelservice",str(cfg)],capture_output=True,text=True,timeout=30)
                if result.returncode: raise RuntimeError((result.stderr or result.stdout or "WireGuard ناموفق").strip()[:500])
                ACTIVE={"protocol":protocol,"name":name,"interface":cfg.stem,"connected":True,"routes":routes,"process":None,"config":str(cfg),"windows_service":True}
            else:
                exe=shutil.which("wg-quick")
                if not exe: raise RuntimeError("wg-quick نصب نیست")
                cfg=_safe_config(config.get("config_content"),".conf")
                # wg-quick up generally requires elevated privileges; don't silently elevate.
                result=subprocess.run([exe,"up",str(cfg)],capture_output=True,text=True,timeout=45)
                if result.returncode: raise RuntimeError((result.stderr or result.stdout or "wg-quick ناموفق؛ دسترسی لازم را بررسی کنید").strip()[:500])
                ACTIVE={"protocol":protocol,"name":name,"interface":cfg.stem,"connected":True,"routes":routes,"process":None,"config":str(cfg)}
        elif protocol=="openvpn":
            exe=shutil.which("openvpn") or (shutil.which("openvpn.exe") if kind=="windows" else None)
            if not exe: raise RuntimeError("OpenVPN نصب نیست")
            cfg=_safe_config(config.get("config_content"),".ovpn")
            proc=subprocess.Popen([exe,"--config",str(cfg),"--writepid",str(cfg.with_suffix(".pid"))],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,shell=False)
            ACTIVE={"protocol":protocol,"name":name,"interface":None,"connected":False,"routes":routes,"process":proc,"config":str(cfg),"started":time.time()}
        elif kind=="windows":
            # Windows native RAS requires a pre-created phonebook entry. No password is persisted.
            profile=str(config.get("profile_name") or config.get("host") or "")
            if not profile or any(c in profile for c in '"\r\n'): raise ValueError("نام اتصال VPN ویندوز یا سرور لازم است")
            exe=shutil.which("rasdial")
            if not exe: raise RuntimeError("rasdial در Windows پیدا نشد")
            args=[exe,profile]
            if config.get("username"): args += [str(config["username"]),str(config.get("password") or "")]
            result=subprocess.run(args,capture_output=True,text=True,timeout=45)
            if result.returncode: raise RuntimeError((result.stderr or result.stdout or "اتصال RAS ناموفق").strip()[:500])
            ACTIVE={"protocol":protocol,"name":profile,"interface":None,"connected":True,"routes":routes,"process":None,"ras":True}
        else:
            raise RuntimeError(f"اتصال {protocol} در {platform.system()} پشتیبانی اجرایی ندارد؛ Linux نیازمند NetworkManager و تنظیم قبلی است")
        return status()

def _interfaces():
    # Cross-platform best effort: report addresses without shell invocation.
    try:
        if shutil.which("ip"):
            out=subprocess.run(["ip","-o","-4","addr","show"],capture_output=True,text=True,timeout=3).stdout
            return [{"name":m.group(1),"ip":m.group(2)} for line in out.splitlines() if (m:=re.search(r"\d+:\s+([^ ]+).*?inet ([0-9.]+)",line))]
        if platform.system().lower()=="windows" and shutil.which("ipconfig"):
            out=subprocess.run(["ipconfig"],capture_output=True,text=True,timeout=3).stdout
            return [{"name":"Windows adapter","ip":x} for x in re.findall(r"(?:IPv4 Address|IPv4-адрес)[^:]*:\s*([0-9.]+)",out)]
    except Exception: pass
    return []

def status():
    with LOCK:
        active=ACTIVE
        if active and active.get("process"):
            proc=active["process"]
            if proc.poll() is not None: active["connected"]=False; active["error"]="فرایند VPN پایان یافت"
            elif time.time()-active.get("started",0)>3: active["connected"]=True
        interfaces=_interfaces()
        return {"connected":bool(active and active.get("connected")),"connecting":bool(active and active.get("process") and active["process"].poll() is None and not active.get("connected")),"active":({k:v for k,v in active.items() if k not in ("process","config","started","windows_service","ras")} if active else None),"interfaces":interfaces,"interface_ip":next((x["ip"] for x in interfaces if active and active.get("interface")==x["name"]),None),"routes":active.get("routes",[]) if active else []}

def disconnect():
    global ACTIVE
    with LOCK:
        active=ACTIVE
        if not active: return status()
        protocol=active["protocol"]
        try:
            if protocol=="wireguard":
                if active.get("windows_service"):
                    exe=shutil.which("wireguard")
                    subprocess.run([exe,"/uninstalltunnelservice",Path(active["config"]).stem],capture_output=True,timeout=30)
                else:
                    exe=shutil.which("wg-quick")
                    if exe: subprocess.run([exe,"down",active["config"]],capture_output=True,timeout=30)
            elif protocol=="openvpn":
                p=active.get("process")
                if p and p.poll() is None:
                    p.terminate()
                    try:p.wait(timeout=8)
                    except subprocess.TimeoutExpired:p.kill();p.wait(timeout=3)
            elif active.get("ras"):
                exe=shutil.which("rasdial")
                if exe: subprocess.run([exe,active["name"],"/disconnect"],capture_output=True,timeout=20)
        finally:
            cfg=active.get("config")
            if cfg:
                for path in (Path(cfg),Path(cfg).with_suffix(".pid")):
                    try:path.unlink(missing_ok=True)
                    except OSError:pass
            ACTIVE=None
        return status()

def list_interfaces(): return _interfaces()
def get_active_vpn(): return status().get("active")
def list_profiles():
    with LOCK:
        _load();return [{"id":k,"name":v.get("name",k),"protocol":v.get("protocol"),"host":v.get("host",""),"routes":v.get("routes",[]),"profile_name":v.get("profile_name","")} for k,v in PROFILES.items()]
def save_profile(data):
    if not isinstance(data,dict):raise ValueError("پروفایل نامعتبر")
    pid=str(data.get("id") or "")
    if not _ID.fullmatch(pid): raise ValueError("شناسه پروفایل نامعتبر")
    protocol=str(data.get("protocol","")).lower()
    if protocol not in _ALLOWED:raise ValueError("پروتکل نامعتبر")
    # Exclude secrets and uploaded configs from persistent storage.
    safe={"name":str(data.get("name") or pid)[:64],"protocol":protocol,"host":str(data.get("host") or "")[:253],"routes":_routes(data.get("routes")),"profile_name":str(data.get("profile_name") or "")[:128]}
    with LOCK:_load();PROFILES[pid]=safe;_save()
    return {"id":pid,**safe}
def delete_profile(pid):
    with LOCK:
        _load()
        if pid not in PROFILES:return False
        del PROFILES[pid];_save();return True
