"""SQLite persistence for discovered devices (stdlib sqlite3 only).

The database file (devices.db in the project root) is created automatically
when the backend starts. Connections are created per call and guarded by a
module-level lock, so access is thread-safe from FastAPI worker threads.
"""
import csv
import io
import json
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "devices.db"
_LOCK = threading.Lock()

# Stored classification values: mikrotik_candidate | non_mikrotik | special
_SCHEMA = """
CREATE TABLE IF NOT EXISTS devices (
    ip TEXT PRIMARY KEY,
    ping_ok INTEGER NOT NULL DEFAULT 0,
    open_ports TEXT NOT NULL DEFAULT '[]',
    port_states TEXT NOT NULL DEFAULT '{}',
    classification TEXT NOT NULL,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL,
    seen_count INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_devices_classification ON devices(classification);
"""


def _now():
    return datetime.now(timezone.utc).isoformat()


@contextmanager
def _connect(db_path=DB_PATH):
    with _LOCK:
        conn = sqlite3.connect(db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()


def init_db(db_path=DB_PATH):
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    with _LOCK:
        conn = sqlite3.connect(db_path, timeout=30)
        try:
            conn.executescript(_SCHEMA)
            conn.commit()
        finally:
            conn.close()


# Backwards compatibility: legacy Persian labels / old keys map to internal keys.
LEGACY_CLASSIFICATION_LABELS = {
    "نامزد MikroTik": "mikrotik_candidate",
    "دستگاه MikroTik": "mikrotik_candidate",
    "غیر MikroTik": "non_mikrotik",
    "احتمالاً غیر MikroTik": "non_mikrotik",
    "ویژه": "special",
}
# Public display label (new wording).
CLASSIFICATION_LABELS = {
    "mikrotik_candidate": "دستگاه MikroTik",
    "non_mikrotik": "غیر MikroTik",
    "special": "ویژه",
}

def classification_label(value):
    """Persian display label for a classification, tolerating legacy values."""
    if value in LEGACY_CLASSIFICATION_LABELS:
        value = LEGACY_CLASSIFICATION_LABELS[value]
    return CLASSIFICATION_LABELS.get(value, value or "")

def _normalize_classification(classification, ping_ok):
    if classification in LEGACY_CLASSIFICATION_LABELS:
        classification = LEGACY_CLASSIFICATION_LABELS[classification]
    if classification in ("mikrotik_candidate", "non_mikrotik", "special"):
        return classification
    if classification == "no_ping":
        return "non_mikrotik"
    if classification == "winbox_open_api_closed":
        return "special"
    if classification == "potential_non_mikrotik":
        return "non_mikrotik"
    return "mikrotik_candidate" if ping_ok else "non_mikrotik"


def upsert_device(ip, ping_ok, open_ports, port_states=None, classification=None, db_path=DB_PATH):
    """Insert a new device or merge into the existing row (dedupe by IP).

    - open_ports: iterable of open port numbers; merged as a union.
    - port_states: {port: state}; later (newer) states win.
    - classification is remapped to mikrotik_candidate/non_mikrotik/special.
    - seen_count is incremented on every re-encounter.
    """
    ping_ok = bool(ping_ok)
    open_ports = sorted({int(p) for p in (open_ports or [])})
    port_states = {str(k): str(v) for k, v in (port_states or {}).items()}
    classification = _normalize_classification(classification, ping_ok)
    ts = _now()
    with _connect(db_path) as conn:
        row = conn.execute("SELECT open_ports, port_states, seen_count, ping_ok FROM devices WHERE ip=?", (ip,)).fetchone()
        if row:
            merged_ports = sorted({int(p) for p in json.loads(row["open_ports"])} | set(open_ports))
            merged_states = {**json.loads(row["port_states"]), **port_states}
            if set(merged_ports) & {8291, 8728}:
                classification = "mikrotik_candidate"
            elif row["classification"] == "mikrotik_candidate":
                classification = "mikrotik_candidate"
            elif classification != "special" and row["classification"] == "special":
                classification = "special"
            seen_count = row["seen_count"] + 1
            conn.execute(
                """UPDATE devices SET ping_ok=?, open_ports=?, port_states=?, classification=?,
                   last_seen=?, seen_count=? WHERE ip=?""",
                (1 if ping_ok else row["ping_ok"], json.dumps(merged_ports),
                 json.dumps(merged_states), classification, ts, seen_count, ip),
            )
        else:
            conn.execute(
                """INSERT INTO devices (ip, ping_ok, open_ports, port_states, classification,
                   first_seen, last_seen, seen_count) VALUES (?,?,?,?,?,?,?,?)""",
                (ip, int(ping_ok), json.dumps(open_ports), json.dumps(port_states),
                 classification, ts, ts, 1),
            )
    return {"ip": ip, "ping_ok": ping_ok, "open_ports": open_ports, "classification": classification}


SORT_COLUMNS = {
    "ip": "ip",
    "ping": "ping_ok",
    "ports": "open_ports",          # JSON array; sorted as text (client re-sorts numerically)
    "ports_count": "json_array_length(open_ports)",
    "classification": "classification",
    "first_seen": "first_seen",
    "last_seen": "last_seen",
    "seen_count": "seen_count",
}

def _sort_clause(sort, order):
    col = SORT_COLUMNS.get(sort or "ip", "ip")
    direction = "DESC" if (order or "asc").lower() == "desc" else "ASC"
    return f" ORDER BY {col} {direction}, ip ASC"

def query_devices(classification=None, has_port=None, q=None, limit=500, offset=0, ping_ok=None,
                  new_only=False, sort="ip", order="asc", db_path=DB_PATH):
    """Filter devices. has_port filters by open port number; q is an ip substring.
    ping_ok: True -> only ping responders, False -> only non-responders, None -> all.
    new_only: only devices first discovered recently (seen_count == 1 or first_seen
    within NEW_DEVICE_WINDOW seconds) — the "دستگاه‌های جدید" report.
    sort: ip | ping | ports | ports_count | classification | first_seen | last_seen | seen_count
    order: asc | desc
    """
    clauses, params = [], []
    if ping_ok is not None:
        clauses.append("ping_ok=?")
        params.append(1 if ping_ok else 0)
    if classification:
        clauses.append("classification=?")
        params.append(classification)
    if has_port is not None:
        clauses.append("EXISTS (SELECT 1 FROM json_each(devices.open_ports) WHERE json_each.value=?)")
        params.append(int(has_port))
    if q:
        clauses.append("ip LIKE ?")
        params.append(f"%{q}%")
    if new_only:
        clauses.append("(seen_count = 1 OR first_seen >= ?)")
        params.append(_now()[:10])  # same UTC day granularity as ISO timestamps
    where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
    limit = max(1, min(int(limit), 10000))
    offset = max(0, int(offset))
    order_clause = _sort_clause(sort, order)
    with _connect(db_path) as conn:
        rows = conn.execute(
            f"SELECT * FROM devices{where}{order_clause} LIMIT ? OFFSET ?", (*params, limit, offset)
        ).fetchall()
        total = conn.execute(f"SELECT COUNT(*) AS c FROM devices{where}", params).fetchone()["c"]
        new_count = conn.execute(
            "SELECT COUNT(*) AS c FROM devices WHERE seen_count = 1 OR first_seen >= ?",
            (_now()[:10],),
        ).fetchone()["c"]
    devices = [
        {"ip": r["ip"], "ping_ok": bool(r["ping_ok"]), "open_ports": json.loads(r["open_ports"]),
         "port_states": json.loads(r["port_states"]), "classification": r["classification"],
         "first_seen": r["first_seen"], "last_seen": r["last_seen"], "seen_count": r["seen_count"]}
        for r in rows
    ]
    return {"total": total, "new_count": new_count, "limit": limit, "offset": offset, "devices": devices}


def add_manual_device(ip, open_ports=None, classification="mikrotik_candidate", db_path=DB_PATH):
    """Manually register a device (does not bump seen_count if already known)."""
    import ipaddress
    ipaddress.ip_address(ip)  # raises ValueError for invalid input
    ping_ok = True
    open_ports = sorted({int(p) for p in (open_ports or [])})
    classification = _normalize_classification(classification, ping_ok)
    ts = _now()
    with _connect(db_path) as conn:
        row = conn.execute("SELECT open_ports, port_states, classification FROM devices WHERE ip=?", (ip,)).fetchone()
        if row:
            open_ports = sorted({int(p) for p in json.loads(row["open_ports"])} | set(open_ports))
            classification = classification if classification != "mikrotik_candidate" else row["classification"]
            conn.execute("UPDATE devices SET open_ports=?, port_states=?, classification=? WHERE ip=?",
                         (json.dumps(open_ports), json.dumps({}), classification, ip))
        else:
            conn.execute(
                """INSERT INTO devices (ip, ping_ok, open_ports, port_states, classification,
                   first_seen, last_seen, seen_count) VALUES (?,?,?,?,?,?,?,?)""",
                (ip, int(ping_ok), json.dumps(open_ports), "{}", classification, ts, ts, 1),
            )
    return {"ip": ip, "open_ports": open_ports, "classification": classification}

def devices_to_csv(devices):
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["ip", "ping_ok", "open_ports", "port_8291", "port_8728", "classification", "first_seen", "last_seen", "seen_count"])
    for d in devices:
        states = d.get("port_states", {})
        writer.writerow([
            d["ip"], "yes" if d["ping_ok"] else "no", " ".join(map(str, d["open_ports"])),
            states.get("8291", ""), states.get("8728", ""), classification_label(d["classification"]),
            d["first_seen"], d["last_seen"], d["seen_count"],
        ])
    return b"\xef\xbb\xbf" + buf.getvalue().encode("utf-8")


def upsert_devices_batch(hosts, db_path=DB_PATH):
    """Upsert many hosts in ONE transaction (single commit) for speed.

    hosts: iterable of dicts with keys ip, ping_ok, open_ports, port_states,
    classification (same shapes as upsert_device accepts).
    Merging semantics match upsert_device: open ports union, port states merged
    (newer win), seen_count incremented, classification remapped. Merging also
    happens between rows in the batch itself (dedupe by IP).
    """
    merged = {}  # ip -> row dict
    for host in hosts:
        ip = host["ip"]
        ping_ok = bool(host.get("ping_ok"))
        open_ports = sorted({int(p) for p in (host.get("open_ports") or [])})
        port_states = {str(k): str(v) for k, v in (host.get("port_states") or {}).items()}
        classification = _normalize_classification(host.get("classification"), ping_ok)
        row = merged.get(ip)
        if row is None:
            merged[ip] = {"ping_ok": ping_ok, "open_ports": set(open_ports),
                          "port_states": dict(port_states), "classification": classification,
                          "seen": 1}
        else:
            row["open_ports"] |= set(open_ports)
            row["port_states"].update(port_states)
            row["ping_ok"] = row["ping_ok"] or ping_ok
            if set(open_ports) & {8291, 8728}:
                row["classification"] = "mikrotik_candidate"
            elif row["classification"] == "mikrotik_candidate":
                pass
            elif classification == "special" or row["classification"] == "special":
                row["classification"] = "special" if classification == "special" else row["classification"]
            row["seen"] += 1
    if not merged:
        return []
    ts = _now()
    results = []
    with _connect(db_path) as conn:
        conn.execute("PRAGMA synchronous=NORMAL")
        existing = {}
        ips = list(merged)
        for i in range(0, len(ips), 500):
            chunk = ips[i:i + 500]
            rows = conn.execute(
                f"SELECT ip, open_ports, port_states, seen_count, ping_ok, classification FROM devices WHERE ip IN ({','.join('?' * len(chunk))})",
                chunk,
            ).fetchall()
            existing.update({r["ip"]: r for r in rows})
        updates, inserts = [], []
        for ip, row in merged.items():
            old = existing.get(ip)
            if old:
                open_ports = sorted(row["open_ports"] | {int(p) for p in json.loads(old["open_ports"])})
                port_states = {**json.loads(old["port_states"]), **row["port_states"]}
                classification = row["classification"]
                if set(open_ports) & {8291, 8728}:
                    classification = "mikrotik_candidate"
                elif old["classification"] == "mikrotik_candidate":
                    classification = "mikrotik_candidate"
                elif classification != "special" and old["classification"] == "special":
                    classification = "special"
                updates.append((1 if row["ping_ok"] else old["ping_ok"], json.dumps(open_ports),
                                json.dumps(port_states), classification, ts,
                                old["seen_count"] + row["seen"], ip))
            else:
                open_ports = sorted(row["open_ports"])
                inserts.append((ip, int(row["ping_ok"]), json.dumps(open_ports),
                                json.dumps(row["port_states"]), row["classification"], ts, ts, row["seen"]))
        if updates:
            conn.executemany(
                """UPDATE devices SET ping_ok=?, open_ports=?, port_states=?, classification=?,
                   last_seen=?, seen_count=? WHERE ip=?""", updates)
        if inserts:
            conn.executemany(
                """INSERT INTO devices (ip, ping_ok, open_ports, port_states, classification,
                   first_seen, last_seen, seen_count) VALUES (?,?,?,?,?,?,?,?)""", inserts)
    for ip, row in merged.items():
        results.append({"ip": ip, "ping_ok": row["ping_ok"],
                        "open_ports": sorted(row["open_ports"]),
                        "classification": row["classification"]})
    return results
