from __future__ import annotations

import sys
from pathlib import Path

# --- Path bootstrap: make this file runnable in every supported way ---
#   python backend/main.py            (from project root)
#   python main.py                    (from inside backend/)
#   python -m backend.main            (from project root)
ROOT_DIR = Path(__file__).resolve().parent.parent
BACKEND_DIR = Path(__file__).resolve().parent
for _p in (str(ROOT_DIR), str(BACKEND_DIR)):
    if _p not in sys.path:
        sys.path.insert(0, _p)

from concurrent.futures import ThreadPoolExecutor
from threading import Lock, Event
from datetime import datetime, timezone
from uuid import uuid4

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from pydantic import BaseModel, Field

# --- Robust imports: package-relative first, plain fallback for direct run ---
try:
    from backend import db
except ImportError:
    import db

from scanner_lib import ScanConfig, ScanReport, scan_targets  # package-level API
from scanner_lib.constants import MAX_TARGETS
from scanner_lib.parser import parse_targets
from scanner_lib.reports import REPORT_KEYS, csv_bytes

try:
    from backend import vpn_manager
except ImportError:
    import vpn_manager

app=FastAPI(title="Authorized IPv4 Scanner")
app.add_middleware(CORSMiddleware,allow_origins=["*"],allow_methods=["*"],allow_headers=["*"],allow_credentials=False)

# Chrome/Edge "Private Network Access": public UI (e.g. http://185.x:5001) calling http://127.0.0.1:8001
# requires Access-Control-Allow-Private-Network on preflight and responses.
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response as StarletteResponse

class PrivateNetworkAccessMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        origin = request.headers.get("origin", "*")
        if request.method == "OPTIONS" and request.headers.get("access-control-request-private-network", "").lower() == "true":
            resp = StarletteResponse(status_code=204)
            resp.headers["Access-Control-Allow-Origin"] = origin
            resp.headers["Access-Control-Allow-Methods"] = "GET,POST,PUT,PATCH,DELETE,OPTIONS"
            resp.headers["Access-Control-Allow-Headers"] = request.headers.get("access-control-request-headers", "*")
            resp.headers["Access-Control-Allow-Private-Network"] = "true"
            resp.headers["Access-Control-Max-Age"] = "86400"
            return resp
        response = await call_next(request)
        response.headers["Access-Control-Allow-Private-Network"] = "true"
        if origin and "access-control-allow-origin" not in {k.lower() for k in response.headers.keys()}:
            response.headers["Access-Control-Allow-Origin"] = origin
        return response

app.add_middleware(PrivateNetworkAccessMiddleware)
JOBS={}; GUARD=Lock(); EXECUTOR=ThreadPoolExecutor(max_workers=4)
db.init_db()

@app.on_event("startup")
def startup():
    db.init_db()
def now(): return datetime.now(timezone.utc).isoformat()
class StartRequest(BaseModel):
    targets:str=Field(min_length=1)
    ports:list[int]=Field(default_factory=lambda:[8291,8728],min_length=1,max_length=128)
    workers:int=Field(default=32,ge=1,le=256)
    ping_timeout_ms:int=Field(default=1000,ge=100,le=10000)
    port_timeout:float=Field(default=1.0,ge=.1,le=10)
    max_targets:int=Field(default=MAX_TARGETS,ge=1,le=MAX_TARGETS)
def public(job):
    report=job.get("report")
    return {"scan_id":job["id"],"status":job["status"],"started_at":job.get("started_at"),"ended_at":job.get("ended_at"),"progress":job["progress"],"records":[{"ip":x.ip,"classification":x.classification,"ping_responded":x.ping_responded,"open_ports":[{"port":p,"state":s} for p,s in x.ports.items() if s=="open"],"states":{"8291":x.ports.get(8291,"not_scanned"),"8728":x.ports.get(8728,"not_scanned")},"port_states":x.ports,"error":x.error} for x in report.records] if report else [],"summary":{k:sum(1 for x in report.records if predicate(x)) for k,predicate in [("ping_responders",lambda x:x.ping_responded),("mikrotik_candidates",lambda x:x.classification=="mikrotik_candidate"),("potential_non_mikrotik",lambda x:x.classification=="potential_non_mikrotik"),("winbox_open_api_closed",lambda x:x.ports.get(8291)=="open" and x.ports.get(8728)!="open")]} if report else {}}
def run(job,targets,config):
    try:
        with GUARD:
            if job["cancel_event"].is_set():
                job["status"]="canceled";job["ended_at"]=now();return
            job["status"]="running";job["started_at"]=now()
        def progress(p):
            with GUARD: job["progress"]=dict(p)
        report=scan_targets(targets,config,progress,job["cancel_event"])
        # Attach the report and live summary BEFORE persistence so the UI cards
        # are populated at 100% progress even if DB work is slow or fails.
        hosts=[{"ip":h.ip,"ping_ok":h.ping_responded,"open_ports":list(h.open_ports),
                "port_states":{str(port):state for port,state in h.ports.items()},
                "classification":h.classification}
               for h in report.records if h.ping_responded]
        with GUARD:
            job["report"]=report
            job["progress"]={"completed":report.completed,"total":report.total_targets,"ping_responders":report.ping_responders}
        # Persist every ping responder in ONE batched transaction (fast, single commit).
        try:
            db.upsert_devices_batch(hosts)
        except Exception as db_err:  # persistence failure must not hang the job
            with GUARD: job.setdefault("warnings",[]).append(f"db persist failed: {db_err}")
        finally:
            with GUARD:
                job["status"]="canceled" if job["cancel_event"].is_set() else "done"
                job["ended_at"]=now()
    except Exception as e:
        # Robust terminal transition: status ALWAYS becomes error (never stuck on running).
        try:
            with GUARD:
                job["status"]="error";job["error"]=str(e);job["ended_at"]=now()
        except Exception:
            pass
    finally:
        if job.get("status") not in ("done","error","canceled"):
            with GUARD:
                job["status"]="error";job.setdefault("error","unexpected scan termination");job["ended_at"]=now()
@app.get("/health")
def health(): return {"status":"ok"}
@app.get("/devices")
def get_devices(
    classification: str | None = Query(default=None, pattern="^(mikrotik_candidate|non_mikrotik|special)$"),
    has_port: int | None = Query(default=None, ge=1, le=65535),
    q: str | None = Query(default=None, max_length=64),
    ping_ok: bool | None = Query(default=True),
    new_only: bool = Query(default=False, description="فقط دستگاه‌های جدید"),
    sort: str = Query(default="ip", pattern="^(ip|ping|ports|ports_count|classification|first_seen|last_seen|seen_count)$"),
    order: str = Query(default="asc", pattern="^(asc|desc)$"),
    limit: int = Query(default=500, ge=1, le=10000),
    offset: int = Query(default=0, ge=0),
):
    return db.query_devices(classification, has_port, q, limit, offset, ping_ok=ping_ok,
                            new_only=new_only, sort=sort, order=order)

@app.get("/devices/export.csv")
def export_devices(
    classification: str | None = Query(default=None, pattern="^(mikrotik_candidate|non_mikrotik|special)$"),
    has_port: int | None = Query(default=None, ge=1, le=65535),
    q: str | None = Query(default=None, max_length=64),
    ping_ok: bool | None = Query(default=True),
    new_only: bool = Query(default=False, description="فقط دستگاه‌های جدید"),
    sort: str = Query(default="ip", pattern="^(ip|ping|ports|ports_count|classification|first_seen|last_seen|seen_count)$"),
    order: str = Query(default="asc", pattern="^(asc|desc)$"),
    limit: int = Query(default=10000, ge=1, le=10000),
    offset: int = Query(default=0, ge=0),
):
    result = db.query_devices(classification, has_port, q, limit, offset, ping_ok=ping_ok,
                              new_only=new_only, sort=sort, order=order)
    filename = "new_devices.csv" if new_only else "devices.csv"
    return Response(db.devices_to_csv(result["devices"]), media_type="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"'})

@app.get("/devices/new/count")
def new_devices_count():
    """Summary metric: دستگاه‌های جدید اضافه‌شده در این اسکن/دوره."""
    result = db.query_devices(new_only=True, limit=1)
    return {"new_count": result["new_count"]}

class ManualDeviceRequest(BaseModel):
    ip: str = Field(max_length=45)
    open_ports: list[int] = Field(default_factory=list)
    classification: str = Field(default="mikrotik_candidate", max_length=64)

@app.post("/devices/manual")
def add_manual_device(body: ManualDeviceRequest):
    try:
        return db.add_manual_device(body.ip.strip(), body.open_ports, body.classification)
    except ValueError as e:
        raise HTTPException(422, f"ورودی نامعتبر: {e}")

@app.get("/devices/{ip}")
def get_device(ip: str):
    result = db.query_devices(q=ip, limit=10000)
    for device in result["devices"]:
        if device["ip"] == ip:
            return device
    raise HTTPException(404, "دستگاه یافت نشد")

@app.post("/scans",status_code=202)
def start(body:StartRequest):
    try: targets=parse_targets(body.targets,body.max_targets)
    except ValueError as e: raise HTTPException(422,str(e))
    ports=tuple(dict.fromkeys(body.ports+[8291,8728]))
    if any(not 1<=p<=65535 for p in ports): raise HTTPException(422,"پورت باید بین ۱ تا ۶۵۵۳۵ باشد")
    sid=str(uuid4());job={"id":sid,"status":"queued","started_at":None,"ended_at":None,"cancel_event":Event(),"progress":{"completed":0,"total":len(targets),"ping_responders":0},"report":None}
    with GUARD: JOBS[sid]=job
    EXECUTOR.submit(run,job,targets,ScanConfig(ports,body.workers,body.ping_timeout_ms,body.port_timeout,body.max_targets))
    return {"scan_id":sid,"status":"queued","total_targets":len(targets)}
@app.post("/scans/{scan_id}/cancel")
def cancel(scan_id:str):
    with GUARD:
        job=JOBS.get(scan_id)
        if not job: raise HTTPException(404,"شناسه اسکن یافت نشد")
        if job["status"] in ("queued","running"):
            job["cancel_event"].set()
            if job["status"]=="queued":job["status"]="canceled";job["ended_at"]=now()
        return {"scan_id":scan_id,"status":job["status"],"cancel_requested":job["cancel_event"].is_set()}
@app.get("/scans/{scan_id}")
def status(scan_id:str):
    job=JOBS.get(scan_id)
    if not job: raise HTTPException(404,"شناسه اسکن یافت نشد")
    return public(job)|({"error":job["error"]} if job.get("error") else {})
@app.get("/scans/{scan_id}/reports/{key}")
def download(scan_id:str,key:str):
    job=JOBS.get(scan_id)
    if not job: raise HTTPException(404,"شناسه اسکن یافت نشد")
    if key not in REPORT_KEYS: raise HTTPException(404,"گزارش ناشناخته")
    if job.get("status") not in ("done","canceled"): raise HTTPException(409,"گزارش هنوز آماده نیست")
    return Response(csv_bytes(job["report"],key),media_type="text/csv; charset=utf-8",headers={"Content-Disposition":f'attachment; filename="{key}.csv"'})

# ---------------- VPN connection manager ----------------
class VpnConnectRequest(BaseModel):
    protocol: str = Field(pattern="^(wireguard|openvpn|pptp|l2tp|sstp)$")
    name: str = Field(default="Remote VPN", max_length=64)
    host: str | None = Field(default=None, max_length=253)
    username: str | None = Field(default=None, max_length=128)
    password: str | None = Field(default=None, max_length=128)
    profile_name: str | None = Field(default=None, max_length=128)
    config_content: str | None = Field(default=None, max_length=200_000)
    routes: list[str] | str | None = None

class VpnProfileRequest(BaseModel):
    id: str = Field(pattern="^[a-zA-Z0-9_-]{1,48}$")
    name: str = Field(default="", max_length=64)
    protocol: str = Field(pattern="^(wireguard|openvpn|pptp|l2tp|sstp)$")
    host: str | None = Field(default=None, max_length=253)
    profile_name: str | None = Field(default=None, max_length=128)
    routes: list[str] | str | None = None

@app.get("/api/vpn/status")
def vpn_status():
    return vpn_manager.status()

@app.post("/api/vpn/connect")
def vpn_connect(body: VpnConnectRequest):
    try:
        return vpn_manager.connect(body.model_dump())
    except (ValueError, RuntimeError) as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(500, f"خطای داخلی VPN: {e}")

@app.post("/api/vpn/disconnect")
def vpn_disconnect():
    try:
        return vpn_manager.disconnect()
    except Exception as e:
        raise HTTPException(500, f"خطا در قطع اتصال VPN: {e}")

@app.get("/api/vpn/profiles")
def vpn_profiles_list():
    return {"profiles": vpn_manager.list_profiles()}

@app.post("/api/vpn/profiles")
def vpn_profiles_save(body: VpnProfileRequest):
    try:
        return vpn_manager.save_profile(body.model_dump())
    except ValueError as e:
        raise HTTPException(400, str(e))

@app.delete("/api/vpn/profiles/{profile_id}")
def vpn_profiles_delete(profile_id: str):
    if vpn_manager.delete_profile(profile_id):
        return {"deleted": profile_id}
    raise HTTPException(404, "پروفایل یافت نشد")

# Run with one of:
#   python backend/main.py      (from project root)
#   python main.py              (from inside backend/)
#   python -m backend.main      (from project root)

# ---- Serve embedded UI (same-origin at http://127.0.0.1:8001/) ----
# Avoids Chrome Private Network Access block when UI is on a public host.
try:
    from fastapi.staticfiles import StaticFiles
    from fastapi.responses import FileResponse
    _UI_CANDIDATES = [
        ROOT_DIR / "frontend" / "dist",
        ROOT_DIR / "ui",
        Path(__file__).resolve().parent.parent / "ui",
        Path(__file__).resolve().parent / "ui",
    ]
    if getattr(__import__("sys"), "frozen", False) and hasattr(__import__("sys"), "_MEIPASS"):
        _UI_CANDIDATES.insert(0, Path(__import__("sys")._MEIPASS) / "ui")
    _UI_DIR = next((d for d in _UI_CANDIDATES if d.is_dir() and (d / "index.html").exists()), None)
    if _UI_DIR is not None:
        @app.get("/")
        def _ui_index():
            return FileResponse(_UI_DIR / "index.html")
        app.mount("/assets", StaticFiles(directory=str(_UI_DIR / "assets")), name="ui-assets")
        print(f"[ui] serving frontend from {_UI_DIR}")
    else:
        print("[ui] no frontend dist found — API only")
except Exception as _ui_err:
    print(f"[ui] static mount skipped: {_ui_err}")

if __name__ == "__main__":
    try:
        import uvicorn
    except ImportError:
        raise SystemExit(
            "uvicorn is not installed. Run:  pip install -r requirements.txt  "
            "(or pip install uvicorn[standard])"
        )
    # app_dir guarantees uvicorn can import "backend.main" even when the
    # current working directory is backend/ itself; reload=True still works.
    uvicorn.run(
        "backend.main:app",
        host="127.0.0.1",
        port=8001,
        reload=False,
        app_dir=str(ROOT_DIR),
    )
