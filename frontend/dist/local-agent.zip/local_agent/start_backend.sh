#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "UI+API: http://127.0.0.1:8001/"
[ -x ./MikroTikScannerAgent ] && exec ./MikroTikScannerAgent
command -v python3 >/dev/null || { echo "python3 required"; exit 1; }
[ -d .venv ] || python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
echo "Open http://127.0.0.1:8001/ in your browser"
exec python agent_main.py
