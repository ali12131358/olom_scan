import platform, socket, subprocess
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from threading import Event, Lock
from .models import HostResult, ScanReport


def ping_host(ip, ms):
    timeout = max(.05, ms / 1000)
    cmd = ["ping", "-n", "1", "-w", str(ms), ip] if platform.system().lower().startswith("win") else ["ping", "-c", "1", "-W", str(max(1, int(timeout))), ip]
    try:
        return subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=timeout + 1).returncode == 0, None
    except subprocess.TimeoutExpired:
        return False, "ping timeout"
    except OSError as e:
        return False, f"ping error: {e}"


def probe_port(ip, port, timeout):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        code = s.connect_ex((ip, port))
        if code == 0:
            return "open"
        if code in (111, 61, 10061):
            return "refused"
        if code in (110, 60, 10060):
            return "timeout"
        return "error"
    except socket.timeout:
        return "timeout"
    except OSError:
        return "error"
    finally:
        s.close()


def scan_targets(targets, config, progress=None, cancel_event=None):
    """Scan targets and return completed/partial host results, including on cancellation."""
    cancel_event = cancel_event or Event()
    lock = Lock()
    state = {"done": 0, "responders": 0, "errors": 0}

    def one(ip):
        if cancel_event.is_set():
            return None
        alive, err = ping_host(ip, config.ping_timeout_ms)
        result = HostResult(ip, alive, error=err)
        with lock:
            state["responders"] += int(alive)
            state["errors"] += int(bool(err))
        if alive:
            for port in config.ports:
                if cancel_event.is_set():
                    break
                result.ports[port] = probe_port(ip, port, config.port_timeout)
        with lock:
            state["done"] += 1
            completed = state["done"]
            responders = state["responders"]
        if progress:
            progress({"completed": completed, "total": len(targets), "ping_responders": responders, "last_ip": ip})
        return result

    records = []
    executor = ThreadPoolExecutor(max_workers=config.workers)
    futures = {executor.submit(one, ip) for ip in targets}
    pending = set(futures)
    try:
        while pending:
            finished, pending = wait(pending, timeout=0.1, return_when=FIRST_COMPLETED)
            if cancel_event.is_set():
                for future in pending:
                    future.cancel()
            for future in finished:
                if future.cancelled():
                    continue
                try:
                    result = future.result()
                except Exception:
                    # Keep the report usable even if a worker fails unexpectedly.
                    with lock:
                        state["errors"] += 1
                    continue
                if result is not None:
                    records.append(result)
        # If cancellation happened, queued futures are canceled; running workers finish
        # cooperatively and any result they produced is retained above.
    finally:
        executor.shutdown(wait=True, cancel_futures=True)
    records.sort(key=lambda x: tuple(map(int, x.ip.split("."))))
    return ScanReport(records, len(targets), state["responders"], state["done"], state["errors"], cancel_event.is_set())
